# web-see 测试项目

## 安装

```bash
$ npm install
```
## 运行

```bash
$ npm run start
```
