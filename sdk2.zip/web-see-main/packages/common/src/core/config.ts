import version from '../../../core/package.json';
export const SDK_NAME = 'web-see';
export const SDK_VERSION = version.version;
