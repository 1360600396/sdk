# @websee/common

## 4.0.2

### Patch Changes

- 4.0.2

## 4.0.1

### Patch Changes

- 4.0.1

## 4.0.0

### Major Changes

- 4.0.0

## 3.0.0

### Major Changes

- 3.0.0

## 2.0.0

### Major Changes

- 2.2.0

## 1.2.0

### Minor Changes

- 1.2.0
