# @websee/types

## 4.0.2

### Patch Changes

- 4.0.2
- Updated dependencies
  - @websee/common@4.0.2

## 4.0.1

### Patch Changes

- 4.0.1
- Updated dependencies
  - @websee/common@4.0.1

## 4.0.0

### Major Changes

- 4.0.0

### Patch Changes

- Updated dependencies
  - @websee/common@4.0.0

## 3.0.0

### Major Changes

- 3.0.0

### Patch Changes

- Updated dependencies
  - @websee/common@3.0.0

## 2.0.0

### Patch Changes

- Updated dependencies
  - @websee/common@2.0.0

## 1.2.0

### Minor Changes

- 1.2.0

### Patch Changes

- Updated dependencies
  - @websee/common@1.2.0
