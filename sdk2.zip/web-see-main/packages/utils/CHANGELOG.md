# @websee/utils

## 4.0.2

### Patch Changes

- 4.0.2
- Updated dependencies
  - @websee/common@4.0.2
  - @websee/core@4.0.2
  - @websee/types@4.0.2

## 4.0.1

### Patch Changes

- 4.0.1
- Updated dependencies
  - @websee/common@4.0.1
  - @websee/core@4.0.1
  - @websee/types@4.0.1

## 4.0.0

### Major Changes

- 4.0.0

### Patch Changes

- Updated dependencies
  - @websee/common@4.0.0
  - @websee/core@4.0.0
  - @websee/types@4.0.0

## 3.0.0

### Major Changes

- 3.0.0

### Patch Changes

- Updated dependencies
  - @websee/common@3.0.0
  - @websee/types@3.0.0
  - @websee/core@3.0.0

## 2.0.0

### Major Changes

- 2.2.0

### Patch Changes

- Updated dependencies
  - @websee/common@2.0.0
  - @websee/types@2.0.0
  - @websee/core@2.0.0

## 1.2.0

### Minor Changes

- 1.2.0

### Patch Changes

- Updated dependencies
  - @websee/common@1.2.0
  - @websee/types@1.2.0
  - @websee/core@1.2.0
